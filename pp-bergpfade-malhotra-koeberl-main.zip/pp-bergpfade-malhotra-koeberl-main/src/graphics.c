#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "../header/cmdline.h"
#include "../header/data-read.h"
#include "../header/logic.h"
#include "../header/graphics.h"
#include "../header/dpAlgo.h"
#include "../header/dijkstraAlgo.h"

int **bergdaten;

bool **sperren;

Uint32 mainWindowID;
Uint32 dijkStatsWindowID = 0;
Uint32 dpStatsWindowID = 0;
Uint32 greedyStatsWindowID = 0;

int lastMouseX = -1;
int lastMouseY = -1;
//
const Color GRADIENT[] = {
    {  0,   0,  80 },  // Deep ocean
    {  0,  50, 130 },  // Ocean
    {  0, 100, 180 },  // Shallow sea
    {  0, 140, 160 },  // Coastal water
    { 30, 180, 120 },  // Marshy green
    { 60, 200, 100 },  // Grass
    {110, 180,  60 },  // Farmland
    {160, 160,  40 },  // Hills
    {190, 140,  30 },  // Rocky hills
    {220, 180, 100 },  // Dirt/rock
    {240, 220, 160 },  // Sandstone
    {250, 250, 220 },  // Bare stone
    {255, 255, 255 }   // Snow caps
};
const int NUM_COLORS = sizeof(GRADIENT) / sizeof(Color);

typedef struct {
    SDL_Window* window;
    Uint32 windowID;
    SDL_Renderer* renderer;
} UserPathWindow;

void processAllPaths(SDL_Renderer *ren, int drawPaths) {
    for (int y = 0; y < GRIDROWS; y++) {
        Point start = {0,y};
        Point *myPath = getPathFromStartPoint(start);
        if (myPath == NULL) {
            fprintf(stderr, "Failed to get path from start point (%d, %d)\n", start.x, start.y);
            continue;
        }
        if (drawPaths){
            for (int i = 0; i < GRIDCOLS; i++) {
                SDL_SetRenderDrawColor(ren, 255, 0, 0, 255);
                SDL_RenderDrawPoint(ren, myPath[i].x, myPath[i].y);
            }
        }

        if (myPath != bestPath) free(myPath); // Free the path if it's not the best path
    }
}

void userPath(SDL_Renderer *ren, SDL_Event e) {
    int mouseX = e.button.x;
    int mouseY = e.button.y;

    if (mouseX < 0 || mouseX >= GRIDCOLS || mouseY < 0 || mouseY >= GRIDROWS) {
        printf("Clicked outside of map.\n");
        return;
    }

    Point interactiveStartPoint = {mouseX, mouseY};

    if (useDPAlgo) {
        Point *interactivePath = getPathFromStartPointWithDP(interactiveStartPoint);

        if (interactivePath == NULL) {
            fprintf(stderr, "Failed to get DP path from (%d, %d)\n", mouseX, mouseY);
            return;
        }

        SDL_SetRenderDrawColor(ren, 255, 255, 0, 255);

        for (int i = 0; i < GRIDCOLS - mouseX; i++) {
            SDL_RenderDrawPoint(ren, interactivePath[i].x, interactivePath[i].y);
        }

        SDL_Renderer* statsRen = initOrDestroyStatsWindow(1, "dp");
        drawUserPathStats(statsRen, dpUserPathStats);

        free(interactivePath);
        interactivePath = NULL;
    }
    if (useDijkstra) {
        Path path = dijkstra(interactiveStartPoint);
        if (path.length == 0) {
            fprintf(stderr, "Pfad konnte nicht berechnet werden.\n");
            return;
        }
        SDL_SetRenderDrawColor(ren, 255, 100, 255, 255);
        for (int i = 0; i < path.length; i++) {
            SDL_RenderDrawPoint(ren, path.x[i], path.y[i]);
        }
        SDL_RenderPresent(ren);
         if (interactiveMode) {
        Stats stats = getStatsFromPath(path);
        SDL_Renderer* renderer = initOrDestroyStatsWindow(1, "dijkstra");
        drawUserPathStats(renderer, stats);
    }
        free(path.x);
        free(path.y);
    }

    if(!noGreedy){
        Point *interactiveGreedyPath = getPathFromStartPoint(interactiveStartPoint);
        if (interactiveGreedyPath == NULL) {
            fprintf(stderr, "Failed to get path from (%d, %d)\n", mouseX, mouseY);
            return;
        }
        SDL_SetRenderDrawColor(ren, 0, 0, 255, 255);
        for (int i = 0; i < GRIDCOLS - mouseX; i++) {
            SDL_RenderDrawPoint(ren, interactiveGreedyPath[i].x, interactiveGreedyPath[i].y);
        }

        SDL_Renderer* renderer = initOrDestroyStatsWindow(1, "greedy");
        drawUserPathStats(renderer, greedyUserPathStats);

        free(interactiveGreedyPath);
    }

    SDL_RenderPresent(ren);
}

void markLineAsBlocked(int x1, int y1, int x2, int y2) {
    //Bresenham Algorithmus for line, else if mouse-movement is too fast, there are gonna be gaps left where dijkstra can
    //go through -> fills the gaps
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int sx = x1 < x2 ? 1 : -1;
    int sy = y1 < y2 ? 1 : -1;
    int err = dx - dy;
    
    int x = x1, y = y1;
    while (1) {
        if (x >= 0 && x < GRIDCOLS && y >= 0 && y < GRIDROWS) {
            sperren[y][x] = true;
        }
        
        if (x == x2 && y == y2) break;
        
        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x += sx; }
        if (e2 < dx) { err += dx; y += sy; }
    }
}

bool rightMouseDown = false;

void handleEvent(SDL_Event* e, SDL_Renderer* ren) {
    if(interactiveMode){
        if (e->type == SDL_MOUSEBUTTONDOWN) {
            if ((e->button.button == SDL_BUTTON_RIGHT ) && useDijkstra && !useDPAlgo) {
                rightMouseDown = true;
                int x = e->button.x;
                int y = e->button.y;
                sperren[y][x] = !sperren[y][x];
                SDL_SetRenderDrawColor(ren, sperren[y][x] ? 255 : 255, sperren[y][x] ? 0 : 255, 0, 255);
                SDL_RenderDrawPoint(ren, x, y);
            }
            else if (e->button.button == SDL_BUTTON_LEFT) {
                userPath(ren, *e);
            }
        }
        else if (e->type == SDL_MOUSEBUTTONUP) {
            if (e->button.button == SDL_BUTTON_RIGHT) {
                rightMouseDown = false;
                lastMouseX = -1;
                lastMouseY = -1;
            }
        }
        else if (e->type == SDL_MOUSEMOTION) {
            if (rightMouseDown) {
                int x = e->motion.x;
                int y = e->motion.y;

                if (lastMouseX >= 0 && lastMouseY >= 0) {
                    
                    SDL_SetRenderDrawColor(ren, 255, 0, 0, 255);
                    SDL_RenderDrawLine(ren, lastMouseX, lastMouseY, x, y);
                    markLineAsBlocked(lastMouseX, lastMouseY, x, y); 
                }

                lastMouseX = x;
                lastMouseY = y;
            }
        }
    }
}

void drawText (char* text, int value, SDL_Renderer* renderer, int y, SDL_Color color, TTF_Font* font) {
    char buffer[100];
    snprintf(buffer, sizeof(buffer), "%s = %d", text, value);

    SDL_Surface* surface = TTF_RenderText_Blended(font, buffer, color);
    if (!surface) {
        SDL_Log("Failed to render text surface: %s", TTF_GetError());
        return;
    }

    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!texture) {
        SDL_Log("Failed to create texture: %s", SDL_GetError());
        SDL_FreeSurface(surface);
        return;
    }

    SDL_Rect dstRect = {20, y, surface->w, surface->h}; // set width & height
    SDL_RenderCopy(renderer, texture, NULL, &dstRect);

    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}

UserPathWindow getUserPathWindow(char windowTitle[], int X, int Y){
    UserPathWindow userPathWindow;
    userPathWindow.window = SDL_CreateWindow(windowTitle, X, Y, 800, 400, SDL_WINDOW_SHOWN);
    if (!userPathWindow.window) {
        SDL_Log("SDL_CreateWindow failed: %s", SDL_GetError());
    }

    userPathWindow.windowID = SDL_GetWindowID(userPathWindow.window);

    userPathWindow.renderer = SDL_CreateRenderer(userPathWindow.window, -1, SDL_RENDERER_ACCELERATED);
    if (!userPathWindow.renderer) {
        SDL_Log("SDL_CreateRenderer failed: %s", SDL_GetError());
        SDL_DestroyWindow(userPathWindow.window);
    }
    return userPathWindow;
}

SDL_Renderer* initOrDestroyStatsWindow(int init, char windowName[]) {
    static SDL_Renderer* rendererDP = NULL;
    static SDL_Window* windowDP = NULL;

    static SDL_Renderer* rendererDijk = NULL; // renderer for the dijkstra window
    static SDL_Window* windowDijk = NULL;

    static SDL_Renderer* rendererGreedy = NULL;
    static SDL_Window* windowGreedy = NULL;

    if (init) {
        // // Initialize the stats window
        int WINDOW_X = 100 + GRIDCOLS + 5;
        static int WINDOW_Y = 100;

        if (windowName == "dp" && !windowDP) {
            UserPathWindow userPathWindow = getUserPathWindow("User DP Path (Yellow) Stats", WINDOW_X, WINDOW_Y);
            if (!userPathWindow.window || !userPathWindow.renderer) {
                return NULL;
            }
            windowDP = userPathWindow.window;
            rendererDP = userPathWindow.renderer;
            dpStatsWindowID = userPathWindow.windowID;
        }

        if (windowName == "dijkstra" && !windowDijk) {
            if (windowDP) {WINDOW_Y += 400 + 5;} // Adjust Y position if dijkstra window exists
            UserPathWindow userPathWindow = getUserPathWindow("User Dijkstra Path (Pink) Stats", WINDOW_X, WINDOW_Y);
            if (!userPathWindow.window || !userPathWindow.renderer) {
                return NULL;
            }
            windowDijk = userPathWindow.window;
            rendererDijk = userPathWindow.renderer;
            dijkStatsWindowID = userPathWindow.windowID;
        }

        if (windowName == "greedy" && !windowGreedy) {
            if (windowDijk && windowDP) {WINDOW_X -= 800 - 5;} 
            else if (windowDijk || windowDP) {WINDOW_Y += 400 + 5;}
            UserPathWindow userPathWindow = getUserPathWindow("User Greedy Path (Blue) Stats", WINDOW_X, WINDOW_Y);
            if (!userPathWindow.window || !userPathWindow.renderer) {
                return NULL;
            }
            windowGreedy = userPathWindow.window;
            rendererGreedy = userPathWindow.renderer;
            greedyStatsWindowID = userPathWindow.windowID;
        }
        

    } else if (!init) {
        if (windowName == "dijkstra") {
            // Destroy the dijkstra stats window
            if (rendererDijk) {
                SDL_DestroyRenderer(rendererDijk);
                rendererDijk = NULL;
            }
            
            if (windowDijk) {
                SDL_DestroyWindow(windowDijk);
                windowDijk = NULL;
            }
            dijkStatsWindowID = 0; // Reset ID
        }

        if (windowName == "dp") {
            // Destroy the dp stats window
            if (rendererDP) {
                SDL_DestroyRenderer(rendererDP);
                rendererDP = NULL;
            }
            
            if (windowDP) {
                SDL_DestroyWindow(windowDP);
                windowDP = NULL;
            }
            dpStatsWindowID = 0; // Reset ID
        }

        if (windowName == "greedy") {
            // Destroy the greedy stats window
            if (rendererGreedy) {
                SDL_DestroyRenderer(rendererGreedy);
                rendererGreedy = NULL;
            }
            
            if (windowGreedy) {
                SDL_DestroyWindow(windowGreedy);
                windowGreedy = NULL;
            }
            greedyStatsWindowID = 0; // Reset ID
        }
    }

    //return the appropriate renderer based on the window name
    if (windowName == "dijkstra") {
        return rendererDijk;
    } else if (windowName == "dp") {
        return rendererDP;
    } else if (windowName == "greedy") {
        return rendererGreedy;
    }
    return NULL; // If no valid window name is provided
}

int drawUserPathStats(SDL_Renderer* renderer, Stats stats) {
    
    if (!renderer || !stats.elevations || stats.pathLength<2) {
        printf("invalid renderer or stats data");
        return 1;
    }
    
    // Dimensions
    const int winWidth = 800;
    const int winHeight = 400;

    // Colors
    SDL_Color white = {255, 255, 255, 255};
    SDL_Color black = {0, 0, 0, 255};
    SDL_Color blue = {0, 0, 255, 255};

    // Init font once
    static TTF_Font* font = NULL;
    if (!font) {
        if (TTF_Init() != 0) {
            SDL_Log("TTF_Init failed: %s", TTF_GetError());
            return 1;
        }
        font = TTF_OpenFont("../../assets/fonts/Mulish.ttf", 18);  // Or any available .ttf
        if (!font) {
            SDL_Log("TTF_OpenFont failed: %s", TTF_GetError());
            return 1;
        }
    }

    // Clear renderer
    SDL_SetRenderDrawColor(renderer, white.r, white.g, white.b, white.a);
    SDL_RenderClear(renderer);

    // Determine scaling for graph
    int minElevation = stats.elevations[0], maxElevation = stats.elevations[0];
    for (int i = 1; i < stats.pathLength; ++i) {
        if (stats.elevations[i] < minElevation) minElevation = stats.elevations[i];
        if (stats.elevations[i] > maxElevation) maxElevation = stats.elevations[i];
    }

    // Draw elevation line graph
    SDL_SetRenderDrawColor(renderer, blue.r, blue.g, blue.b, blue.a);
    for (int i = 0; i < stats.pathLength - 1; ++i) {
        // my old range of elevations was minElevation to maxElevation
        // my new range of elevations is winHeight * 0.5 to 0
        int y1 = (int)(((float)(stats.elevations[i] - minElevation) / (maxElevation - minElevation)) * (-1*(winHeight * 0.5))) + (winHeight * 0.5);
        int y2 = (int)(((float)(stats.elevations[i+1] - minElevation) / (maxElevation - minElevation)) * (-1*(winHeight * 0.5))) + (winHeight * 0.5);
        int x1 = (int)((i * (float)winWidth) / (stats.pathLength - 1));
        int x2 = (int)(((i + 1) * (float)winWidth) / (stats.pathLength - 1));\
        SDL_RenderDrawLine(renderer, x1, y1, x2, y2);
    }

    int yOffset = (int)(winHeight * 0.6);

    drawText("Total Effort", stats.totalEffort, renderer, yOffset, black, font);
    drawText("Uphill", stats.uphill, renderer, yOffset + 30, black, font);
    drawText("Downhill", stats.downhill, renderer, yOffset + 60, black, font);

    // Present the final render
    SDL_RenderPresent(renderer);
    free(stats.elevations); // Free the elevations array after use

    return 0;
}

 
int main(int argc, char** argv) {

    parse_cmdline(argc, argv);  // Sets fileToBeRead

    bergdaten = ladeDaten(fileToBeRead);

    sperren = malloc(GRIDROWS * sizeof(bool*)); //sperren init
    for (int y = 0; y < GRIDROWS; y++) {
        sperren[y] = malloc(GRIDCOLS * sizeof(bool)); 
    }

    for (int a = 0; a < GRIDROWS; a++) {
        for (int b = 0; b < GRIDCOLS; b++) {
            sperren[a][b] = false;
        }
    }
    if (bergdaten == NULL) return 1;

    int minValue, maxValue;
    getMinMaxVal(bergdaten, &maxValue, &minValue);

    printf("===== Mountain Range: %s =====\n- Statistics\n", fileToBeRead);
    printf("\t- Deepest Point: %d \n\t- Highest Point: %d\n", minValue, maxValue);

    free(fileToBeRead);
    fileToBeRead = NULL;

    // SDL2 Init
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        printf("SDL_Init Error: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Window *win = SDL_CreateWindow("Mountain Range", 100, 100, GRIDCOLS, GRIDROWS, SDL_WINDOW_SHOWN);
    if (!win) {
        printf("Window Error: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    mainWindowID = SDL_GetWindowID(win);

    SDL_Renderer *ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);
    if (!ren) {
        SDL_DestroyWindow(win);
        printf("Renderer Error: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    // Draw the map
    for (int y = 0; y < GRIDROWS; y++) {
        for (int x = 0; x < GRIDCOLS; x++) {

            int h = bergdaten[y][x];

            if (coloredMap){
                double normalizedHeight = (h - minValue) / (double)(maxValue - minValue);
                int mappedGradientSection = (NUM_COLORS - 1) * normalizedHeight;
                double sectionPosition = (NUM_COLORS - 1) * normalizedHeight - mappedGradientSection;


                if (mappedGradientSection < 0) mappedGradientSection = 0;
                if (mappedGradientSection >= NUM_COLORS - 1) mappedGradientSection = NUM_COLORS - 2;

                Color interpolatedColor = {
                    GRADIENT[mappedGradientSection].r + (int)(sectionPosition * (GRADIENT[mappedGradientSection + 1].r - GRADIENT[mappedGradientSection].r)),
                    GRADIENT[mappedGradientSection].g + (int)(sectionPosition * (GRADIENT[mappedGradientSection + 1].g - GRADIENT[mappedGradientSection].g)),
                    GRADIENT[mappedGradientSection].b + (int)(sectionPosition * (GRADIENT[mappedGradientSection + 1].b - GRADIENT[mappedGradientSection].b))
                };

                SDL_SetRenderDrawColor(ren, interpolatedColor.r, interpolatedColor.g, interpolatedColor.b, 255);
                SDL_RenderDrawPoint(ren, x, y);

            } else {

                int gray = 255 * (h - minValue) / (maxValue - minValue);
                SDL_SetRenderDrawColor(ren, gray, gray, gray, 255);
                SDL_RenderDrawPoint(ren, x, y);

            }
        }
    }

    if (!interactiveMode) {
        if (drawOnlyBestPath) {
            processAllPaths(ren, 0);  //greedy draw only best path
            for (int i = 0; i < GRIDCOLS; i++) {
                SDL_SetRenderDrawColor(ren, 0, 255, 0, 255);
                SDL_RenderDrawPoint(ren, bestPath[i].x, bestPath[i].y);
            }
            printf("\n- Best Path (Greedy, green)\n\t-Effort: %d\n\t-Starting row: %d\n\t-Ending Row: %d\n", bestPathEffort, bestPath[0].y, bestPath[GRIDCOLS - 1].y);
        }
        else {
            //draw all paths
            processAllPaths(ren, 1);
            for (int i = 0; i < GRIDCOLS; i++) {
                SDL_SetRenderDrawColor(ren, 0, 255, 0, 255);
                SDL_RenderDrawPoint(ren, bestPath[i].x, bestPath[i].y);
            }
            printf("\n- Best Path (Greedy, green)\n\t-Effort: %d\n\t-Starting row: %d\n\t-Ending Row: %d\n", bestPathEffort, bestPath[0].y, bestPath[GRIDCOLS - 1].y);
        }
        
        if (useDijkstra) {
            //only dijkstra
            Point startPoint = {0, 0};
            Path path = dijkstra(startPoint);
            
            if (path.length > 0) {
                SDL_SetRenderDrawColor(ren, 255, 100, 255, 255);
                for (int i = 0; i < path.length; i++) {
                    SDL_RenderDrawPoint(ren, path.x[i], path.y[i]);
                }
                free(path.x);
                free(path.y);
            }

        }
        if (useDPAlgo) {
            //only Dynamic Programming
            Point* pathWithDP = getPathFromStartPointWithDP((Point){0, 0});
            for (int i = 0; i < GRIDCOLS; i++) {
                SDL_SetRenderDrawColor(ren, 255, 255, 0, 255);
                SDL_RenderDrawPoint(ren, pathWithDP[i].x, pathWithDP[i].y);
            }
            printf("\n- Best Path (Dynamic Programming, yellow)\n\t-Effort: %d\n\t-Starting row: %d\n\t-Ending Row: %d\n", bestPathEffort, pathWithDP[0].y, pathWithDP[GRIDCOLS - 1].y);

            free(pathWithDP);
        }
        
        // Cleanup
        if (bestPath) {
            free(bestPath);
            bestPath = NULL;
        }
    }

    // Main drawing loop
  SDL_Event e;
    int running = 1;
    while (running) {
    while (SDL_PollEvent(&e)) {
        handleEvent(&e, ren);
        if (e.type == SDL_QUIT) running = 0;
        if (e.type == SDL_WINDOWEVENT && e.window.event == SDL_WINDOWEVENT_CLOSE) {
            if (e.window.windowID == mainWindowID) running = 0;
            if (e.window.windowID == dijkStatsWindowID) { initOrDestroyStatsWindow(0, "dijkstra"); }
            if (e.window.windowID == dpStatsWindowID) { initOrDestroyStatsWindow(0, "dp"); }
            if (e.window.windowID == greedyStatsWindowID) { initOrDestroyStatsWindow(0, "greedy"); }
        }
    }

    SDL_RenderPresent(ren);
    SDL_Delay(100);
}   // Cleanup
    
    initOrDestroyStatsWindow(0, "dp"); // Destroy the stats window after drawing
    initOrDestroyStatsWindow(0, "dijkstra");
    initOrDestroyStatsWindow(0, "greedy");

    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    TTF_Quit();
    SDL_Quit();

    if (bestPath) free(bestPath);

    for (int m = 0; m < GRIDROWS; m++) {
        free(bergdaten[m]);
    }
    free(bergdaten);
    for(int k = 0; k< GRIDROWS; k++){
        free(sperren[k]);
    }
    free(sperren);
    return 0;
}
