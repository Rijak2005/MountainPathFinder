#pragma once
extern int **bergdaten;
extern bool **sperren;
#include <SDL2/SDL.h>
#include "../header/logic.h" 

typedef struct {
    int r, g, b;
} Color;

extern int **bergdaten;
SDL_Renderer* initOrDestroyStatsWindow(int init, char windowName[]);
int drawUserPathStats(SDL_Renderer* renderer, Stats stats);


