#pragma once
#include "logic.h"

Point* getPathFromStartPointWithDP(Point start);

extern Stats dpUserPathStats; 